MVP ACADEMY — versión reconstruida desde cero.

Esta versión usa directamente las 2 imágenes proporcionadas por el usuario:
- assets/mvp-baseball-academy.png
- assets/mvp-sports-complex.png

No usa el poster generado anteriormente.
Los iconos de Instagram y WhatsApp están integrados en el HTML/CSS.
